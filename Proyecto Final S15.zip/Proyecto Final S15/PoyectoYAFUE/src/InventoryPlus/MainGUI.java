package InventoryPlus;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class MainGUI {

    private static Inventario inventario;
    private static List<Cliente> clientes;
    private static JFrame ventanaInicial;
    private static List<CabeceraDeFactura> listaFacturas = new ArrayList<>();
    private static List<Proveedor> listadeProveedores = new ArrayList<>();

    public static void main(String[] args) {
        inicializarInventario();
        inicializarClientes();

        // Mostrar la ventana inicial
        mostrarVentanaPrincipal();
    }


    private static void inicializarInventario() {
        inventario = new Inventario();

        // Crear proveedores
        Proveedor proveedor1 = new Proveedor("1", "Proveedor ABC", "555-1234", new ArrayList<>());
        Proveedor proveedor2 = new Proveedor("2", "Proveedor XYZ", "555-5678", new ArrayList<>());

        listadeProveedores.add(proveedor1);
        listadeProveedores.add(proveedor2);

        // Crear productos asociados a proveedores
        inventario.agregarProducto(new Producto("Manzana", 0.5, 100, "Fruta", proveedor1));
        inventario.agregarProducto(new Producto("Arroz", 1.2, 50, "Grano", proveedor2));
        inventario.agregarProducto(new Producto("Leche", 1.5, 30, "Lácteo", proveedor1));
    }


    private static void inicializarClientes() {
        clientes = new ArrayList<>();
        clientes.add(new Cliente("1751834316", "Alejandro Carrera", "0994259393", "alejandrocarrera2004@gmail.com"));
        clientes.add(new Cliente("1719259119", "Pepito Fulano", "0994325228", "pepito24@gmail.com"));
    }


    private static void mostrarVentanaPrincipal() {
        ventanaInicial = new JFrame("Gestión de Ventas y Pedidos");
        ventanaInicial.setSize(400, 300);
        ventanaInicial.setLayout(new GridLayout(3, 1)); // Tres filas, una por cada botón

        // Botones para las acciones
        JButton botonVentas = new JButton("Ventas");
        JButton botonPedido = new JButton("Pedido");
        JButton botonBusqueda = new JButton("Búsqueda");

        // Agregar los botones a la ventana
        ventanaInicial.add(botonVentas);
        ventanaInicial.add(botonPedido);
        ventanaInicial.add(botonBusqueda);

        // Mostrar la ventana principal
        ventanaInicial.setVisible(true);

        // Inicialización de datos predeterminados
        Empleado empleado = new Empleado("12345", "Juan Perez", "0963004475");
        Proveedor proveedor = new Proveedor("1", "Proveedor ABC", "555-1234", new ArrayList<>());
        listadeProveedores.add(proveedor);

        // Eventos para los botones
        botonVentas.addActionListener(e -> mostrarVentanaIngresoCedula());
        botonPedido.addActionListener(e -> manejarPedido(empleado, ventanaInicial));
        botonBusqueda.addActionListener(e -> mostrarPanelBusqueda(ventanaInicial, listaFacturas));
    }


    private static void mostrarPanelBusqueda(JFrame ventanaPrincipal, List<CabeceraDeFactura> listaFacturas) {
        // Crear un nuevo JFrame para el panel de búsqueda
        JFrame ventanaBusqueda = new JFrame("Panel de Búsqueda");
        ventanaBusqueda.setSize(400, 200);
        ventanaBusqueda.setLayout(new GridLayout(2, 1)); // Dos filas, una por cada botón

        // Botones para las opciones de búsqueda
        JButton botonBuscarPorFecha = new JButton("Búsqueda por Fecha");
        JButton botonBuscarPorNumero = new JButton("Búsqueda por Número de Factura");

        // Agregar botones al panel
        ventanaBusqueda.add(botonBuscarPorFecha);
        ventanaBusqueda.add(botonBuscarPorNumero);

        // Mostrar la ventana de búsqueda
        ventanaBusqueda.setVisible(true);

        // Eventos para los botones de búsqueda
        botonBuscarPorFecha.addActionListener(e -> buscarFacturasPorFecha(listaFacturas));

        botonBuscarPorNumero.addActionListener(e -> {
            String numeroString = JOptionPane.showInputDialog(ventanaBusqueda, "Ingrese el número de factura:");
            if (numeroString != null && !numeroString.isEmpty()) {
                try {
                    int numeroFactura = Integer.parseInt(numeroString);
                    CabeceraDeFactura facturaEncontrada = PedidoFacturaManager.buscarFacturaPorNumero(listaFacturas, numeroFactura);

                    if (facturaEncontrada != null) {
                        JOptionPane.showMessageDialog(ventanaBusqueda, facturaEncontrada.toString(), "Factura Encontrada", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(ventanaBusqueda, "No se encontró ninguna factura con ese número.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(ventanaBusqueda, "Número inválido. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Evento al cerrar la ventana de búsqueda
        ventanaBusqueda.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                ventanaBusqueda.dispose(); // Cerrar ventana de búsqueda
                ventanaPrincipal.setVisible(true); // Volver a mostrar la ventana principal
            }
        });
    }


    private static void mostrarVentanaIngresoCedula() {
        JFrame ventanaIngresoCedula = new JFrame("Ingresar Cédula");
        ventanaIngresoCedula.setSize(400, 200);
        ventanaIngresoCedula.setLayout(new BorderLayout());

        JLabel etiquetaCedula = new JLabel("Ingrese la cédula:");
        JTextField campoCedula = new JTextField(10);
        JButton botonValidar = new JButton("Validar");

        JPanel panel = new JPanel();
        panel.add(etiquetaCedula);
        panel.add(campoCedula);
        panel.add(botonValidar);

        ventanaIngresoCedula.add(panel, BorderLayout.CENTER);

        botonValidar.addActionListener(e -> {
            String cedula = campoCedula.getText().trim();
            ventanaIngresoCedula.setVisible(false); // Ocultar la ventana de ingreso de cédula
            validarCedula(cedula);
        });

        ventanaIngresoCedula.setVisible(true);
    }


    private static void validarCedula(String cedula) {
        if (cedula.isEmpty() || !cedula.matches("\\d+")) {
            JOptionPane.showMessageDialog(ventanaInicial, "La cédula debe contener solo números y no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente clienteTemporal = new Cliente(cedula, "", "", "");
        if (!clienteTemporal.validarCedula()) {
            JOptionPane.showMessageDialog(ventanaInicial, "Cédula inválida. Por favor, ingrese una cédula válida.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente clienteExistente = clientes.stream()
                .filter(cliente -> cliente.getCedula().equals(cedula))
                .findFirst()
                .orElse(null);

        if (clienteExistente != null) {
            // Mostrar datos del cliente registrado
            String mensaje = String.format("Usuario registrado:\nCédula: %s\nNombre: %s\nTeléfono: %s\nCorreo: %s",
                    clienteExistente.getCedula(), clienteExistente.getNombre(), clienteExistente.getTelefono(), clienteExistente.getCorreo());
            JOptionPane.showMessageDialog(ventanaInicial, mensaje, "Cliente Registrado", JOptionPane.INFORMATION_MESSAGE);

            // Pasar directamente a la ventana de productos
            ventanaInicial.setVisible(false);
            mostrarVentanaProductos(clienteExistente);
        } else {
            JOptionPane.showMessageDialog(ventanaInicial, "Usuario no registrado. Proceda a registrar sus datos.");
            ventanaInicial.setVisible(false);
            mostrarVentanaRegistro(null, cedula);
        }

        ventanaInicial.setVisible(true);
    }


    private static void mostrarVentanaRegistro(Cliente cliente, String cedulaIngresada) {
        JFrame ventanaRegistro = new JFrame("Registro de Usuario");
        ventanaRegistro.setSize(400, 300);
        ventanaRegistro.setLayout(new GridLayout(5, 2));

        JTextField campoCedula = new JTextField(cliente != null ? cliente.getCedula() : cedulaIngresada);
        JTextField campoNombre = new JTextField(cliente != null ? cliente.getNombre() : "");
        JTextField campoTelefono = new JTextField(cliente != null ? cliente.getTelefono() : "");
        JTextField campoCorreo = new JTextField(cliente != null ? cliente.getCorreo() : "");

        JButton botonSiguiente = new JButton("Siguiente");

        ventanaRegistro.add(new JLabel("Cédula:"));
        ventanaRegistro.add(campoCedula);
        ventanaRegistro.add(new JLabel("Nombre:"));
        ventanaRegistro.add(campoNombre);
        ventanaRegistro.add(new JLabel("Teléfono:"));
        ventanaRegistro.add(campoTelefono);
        ventanaRegistro.add(new JLabel("Correo:"));
        ventanaRegistro.add(campoCorreo);
        ventanaRegistro.add(new JLabel(""));
        ventanaRegistro.add(botonSiguiente);

        ventanaRegistro.setVisible(true);

        botonSiguiente.addActionListener(e -> validarYRegistrarCliente(cliente, cedulaIngresada, campoCedula, campoNombre, campoTelefono, campoCorreo, ventanaRegistro));
    }


    private static void validarYRegistrarCliente(Cliente cliente, String cedulaIngresada, JTextField campoCedula, JTextField campoNombre, JTextField campoTelefono, JTextField campoCorreo, JFrame ventanaRegistro) {
        String cedula = campoCedula.getText().trim();
        String nombre = campoNombre.getText().trim();
        String telefono = campoTelefono.getText().trim();
        String correo = campoCorreo.getText().trim();

        if (cedula.isEmpty() || nombre.isEmpty() || telefono.isEmpty() || correo.isEmpty()) {
            JOptionPane.showMessageDialog(ventanaRegistro, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente tempCliente = new Cliente(cedula, nombre, telefono, correo);

        if (!tempCliente.validarCedula()) {
            JOptionPane.showMessageDialog(ventanaRegistro, "Cédula inválida. Por favor, ingrese una cédula válida.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!tempCliente.validarNombre()) {
            JOptionPane.showMessageDialog(ventanaRegistro, "Nombre inválido. Por favor, ingrese un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!tempCliente.validarTelefono()) {
            JOptionPane.showMessageDialog(ventanaRegistro, "Teléfono inválido. Por favor, ingrese un teléfono válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!tempCliente.validarCorreo()) {
            JOptionPane.showMessageDialog(ventanaRegistro, "Correo inválido. Por favor, ingrese un correo válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente nuevoCliente = cliente != null ? cliente : tempCliente;
        if (cliente == null) {
            clientes.add(nuevoCliente);
        }

        ventanaRegistro.dispose();
        mostrarVentanaProductos(nuevoCliente);
    }


    private static void mostrarVentanaProductos(Cliente cliente) {
        JFrame ventanaProductos = new JFrame("Seleccionar Productos");
        ventanaProductos.setSize(500, 400);
        ventanaProductos.setLayout(new BorderLayout());

        JTextArea areaProductos = new JTextArea();
        areaProductos.setEditable(false);

        StringBuilder productosTexto = new StringBuilder("=== Productos Disponibles ===\n");
        for (Producto producto : inventario.getProductos()) {
            productosTexto.append(producto.getNombre())
                    .append(" - Precio: $").append(producto.getPrecio())
                    .append(" - Stock: ").append(producto.getCantidad())
                    .append("\n");
        }
        areaProductos.setText(productosTexto.toString());

        JTextField campoProducto = new JTextField();
        JTextField campoCantidad = new JTextField();
        JButton botonAgregar = new JButton("Agregar Producto");
        JButton botonFactura = new JButton("Crear Factura");

        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new GridLayout(4, 2));
        panelInferior.add(new JLabel("Producto:"));
        panelInferior.add(campoProducto);
        panelInferior.add(new JLabel("Cantidad:"));
        panelInferior.add(campoCantidad);
        panelInferior.add(botonAgregar);
        panelInferior.add(botonFactura);
        panelInferior.add(new JLabel(""));

        ventanaProductos.add(new JScrollPane(areaProductos), BorderLayout.CENTER);
        ventanaProductos.add(panelInferior, BorderLayout.SOUTH);
        ventanaProductos.setVisible(true);

        CabeceraDeFactura factura = new CabeceraDeFactura(cliente);

        botonAgregar.addActionListener(e -> agregarProductoAFactura(factura, campoProducto, campoCantidad, areaProductos));
        botonFactura.addActionListener(e -> finalizarFactura(factura, ventanaProductos));
    }


    private static void agregarProductoAFactura(CabeceraDeFactura factura, JTextField campoProducto, JTextField campoCantidad, JTextArea areaProductos) {
        String nombreProducto = campoProducto.getText().trim();
        String cantidadTexto = campoCantidad.getText().trim();

        if (nombreProducto.isEmpty() || cantidadTexto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Producto productoSeleccionado = inventario.buscarProducto(nombreProducto);
        if (productoSeleccionado == null) {
            JOptionPane.showMessageDialog(null, "El producto no existe en el inventario.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int cantidad = 0;
        try {
            cantidad = Integer.parseInt(cantidadTexto);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (cantidad <= 0 || cantidad > productoSeleccionado.getCantidad()) {
            JOptionPane.showMessageDialog(null, "Cantidad inválida o stock insuficiente.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Reducir la cantidad en el inventario
        boolean exito = productoSeleccionado.reducirCantidad(cantidad);
        if (exito) {
            // Agregar o actualizar el detalle en la factura
            factura.agregarDetalle(productoSeleccionado, cantidad);

            // Actualizar la lista de productos en el área de texto
            StringBuilder productosActualizados = new StringBuilder("=== Productos Disponibles ===\n");
            for (Producto producto : inventario.getProductos()) {
                productosActualizados.append(producto.getNombre())
                        .append(" - Precio: $").append(producto.getPrecio())
                        .append(" - Stock: ").append(producto.getCantidad())
                        .append("\n");
            }
            areaProductos.setText(productosActualizados.toString());

            JOptionPane.showMessageDialog(null, "Producto agregado a la factura.");
        } else {
            JOptionPane.showMessageDialog(null, "Error al reducir la cantidad del producto.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private static void finalizarFactura(CabeceraDeFactura factura, JFrame ventanaProductos) {
        if (!factura.tieneProductos()) {
            JOptionPane.showMessageDialog(ventanaProductos, "No hay productos en la factura.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Llamar al metodo mostrarVentanaFactura para mostrar la factura
        listaFacturas.add(factura);
        mostrarVentanaFactura(factura);

        // Cerrar la ventana actual
        ventanaProductos.dispose();
    }


    private static void mostrarVentanaFactura(CabeceraDeFactura factura) {
        JFrame ventanaFactura = new JFrame("Factura");
        ventanaFactura.setSize(400, 400);

        JTextArea areaFactura = new JTextArea();
        areaFactura.setEditable(false);
        areaFactura.setText(factura.toString());

        JScrollPane scrollPane = new JScrollPane(areaFactura);
        ventanaFactura.add(scrollPane);

        ventanaFactura.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventanaFactura.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                super.windowClosing(e);
                // Volver a mostrar la ventana inicial
                ventanaInicial.setVisible(true);
            }
        });

        ventanaFactura.setVisible(true);
    }

    private static Pedido pedidoActual;

    private static void manejarPedido(Empleado empleado, JFrame ventanaPrincipal) {
        JFrame ventanaPedido = new JFrame("Realizar Pedido");
        ventanaPedido.setSize(500, 400);
        ventanaPedido.setLayout(new BorderLayout());

        JTextArea areaProductos = new JTextArea();
        areaProductos.setEditable(false);

        // Mostrar los productos disponibles en el inventario
        StringBuilder productosTexto = new StringBuilder("=== Productos Disponibles ===\n");
        for (Producto producto : inventario.getProductos()) {
            productosTexto.append(producto.getNombre())
                    .append(" - Precio: $").append(producto.getPrecio())
                    .append(" - Stock: ").append(producto.getCantidad())
                    .append(" - Proveedor: ").append(producto.getProveedor().getNombre())
                    .append("\n");
        }
        areaProductos.setText(productosTexto.toString());

        JTextField campoProducto = new JTextField();
        JTextField campoCantidad = new JTextField();
        JButton botonAgregar = new JButton("Agregar Producto");
        JButton botonPedido = new JButton("Finalizar Pedido");

        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new GridLayout(4, 2));
        panelInferior.add(new JLabel("Producto:"));
        panelInferior.add(campoProducto);
        panelInferior.add(new JLabel("Cantidad:"));
        panelInferior.add(campoCantidad);
        panelInferior.add(botonAgregar);
        panelInferior.add(botonPedido);
        panelInferior.add(new JLabel(""));

        ventanaPedido.add(new JScrollPane(areaProductos), BorderLayout.CENTER);
        ventanaPedido.add(panelInferior, BorderLayout.SOUTH);
        ventanaPedido.setVisible(true);

        pedidoActual = new Pedido(empleado);

        botonAgregar.addActionListener(e -> agregarProductoAPedido(campoProducto, campoCantidad, ventanaPedido, areaProductos, empleado));
        botonPedido.addActionListener(e -> finalizarPedido(ventanaPedido, ventanaPrincipal));
    }


    private static void agregarProductoAPedido(JTextField campoProducto, JTextField campoCantidad, JFrame ventanaPedido, JTextArea areaProductos, Empleado empleado) {
        String nombreProducto = campoProducto.getText().trim();
        String cantidadTexto = campoCantidad.getText().trim();

        if (nombreProducto.isEmpty() || nombreProducto.matches("\\s+")) {
            JOptionPane.showMessageDialog(ventanaPedido, "El nombre del producto no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!cantidadTexto.matches("\\d+")) {
            JOptionPane.showMessageDialog(ventanaPedido, "La cantidad debe ser un número entero positivo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int cantidad = Integer.parseInt(cantidadTexto);
        Producto productoSeleccionado = inventario.buscarProducto(nombreProducto);

        if (productoSeleccionado == null) {
            int opcion = JOptionPane.showConfirmDialog(ventanaPedido, "El producto no existe en el inventario. ¿Desea crearlo?", "Producto no encontrado", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.NO_OPTION) {
                return;
            }

            String nombreProveedor = JOptionPane.showInputDialog(ventanaPedido, "Ingrese el nombre del proveedor:");
            if (nombreProveedor == null || nombreProveedor.trim().isEmpty() || nombreProveedor.matches("\\s+")) {
                JOptionPane.showMessageDialog(ventanaPedido, "El nombre del proveedor no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Proveedor proveedorExistente = listadeProveedores.stream()
                    .filter(p -> p.getNombre().equalsIgnoreCase(nombreProveedor))
                    .findFirst()
                    .orElse(null);

            if (proveedorExistente == null) {
                String telefonoProveedor = JOptionPane.showInputDialog(ventanaPedido, "Ingrese el teléfono del proveedor:");
                if (!telefonoProveedor.matches("\\d+([-\\s]\\d+)*")) {
                    JOptionPane.showMessageDialog(ventanaPedido, "Teléfono inválido. Use solo números, espacios o guiones.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                proveedorExistente = new Proveedor(String.valueOf(listadeProveedores.size() + 1), nombreProveedor, telefonoProveedor, new ArrayList<>());
                listadeProveedores.add(proveedorExistente);
                JOptionPane.showMessageDialog(ventanaPedido, "Proveedor creado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(ventanaPedido, "Proveedor ya existente, asociado al nuevo producto.");
            }

            String precioTexto = JOptionPane.showInputDialog(ventanaPedido, "Ingrese el precio del producto:");
            if (!precioTexto.matches("\\d+(\\.\\d+)?")) {
                JOptionPane.showMessageDialog(ventanaPedido, "Precio inválido. Ingrese un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double precioProducto = Double.parseDouble(precioTexto);
            Producto nuevoProducto = new Producto(nombreProducto, precioProducto, 0, "Sin categoría", proveedorExistente);
            proveedorExistente.getProductosAsociados().add(nuevoProducto);
            inventario.agregarProducto(nuevoProducto, proveedorExistente);

            JOptionPane.showMessageDialog(ventanaPedido, "Producto creado exitosamente y asociado al proveedor.");
            productoSeleccionado = nuevoProducto;
        }

        pedidoActual.agregarDetalle(productoSeleccionado, cantidad, productoSeleccionado.getProveedor());
        productoSeleccionado.agregarCantidad(cantidad);

        StringBuilder productosActualizados = new StringBuilder("=== Productos Disponibles ===\n");
        for (Producto producto : inventario.getProductos()) {
            productosActualizados.append(producto.getNombre())
                    .append(" - Precio: $").append(producto.getPrecio())
                    .append(" - Stock: ").append(producto.getCantidad())
                    .append(" - Proveedor: ").append(producto.getProveedor().getNombre())
                    .append("\n");
        }
        areaProductos.setText(productosActualizados.toString());
        JOptionPane.showMessageDialog(ventanaPedido, "Producto agregado al pedido.");
    }


    private static void finalizarPedido(JFrame ventanaPedido, JFrame ventanaPrincipal) {
        if (pedidoActual.getDetalles().isEmpty()) {
            JOptionPane.showMessageDialog(ventanaPedido, "No se puede realizar un pedido sin productos. Agregue al menos un producto.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        PedidoFacturaManager.agregarPedido(pedidoActual);
        JOptionPane.showMessageDialog(ventanaPedido, pedidoActual.mostrarPedido(), "Pedido Realizado", JOptionPane.INFORMATION_MESSAGE);
        ventanaPedido.dispose();
        ventanaPrincipal.setVisible(true);
    }


    private static void buscarFacturasPorFecha(List<CabeceraDeFactura> listaFacturas) {
        // Solicitar la fecha al usuario
        String fechaInput = JOptionPane.showInputDialog(null, "Ingrese la fecha en formato DD/MM/AAAA:", "Búsqueda por Fecha", JOptionPane.QUESTION_MESSAGE);

        // Validar la entrada
        if (fechaInput == null || !fechaInput.matches("\\d{2}/\\d{2}/\\d{4}")) {
            JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Use el formato DD/MM/AAAA.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Dividir la entrada en día, mes y año
            String[] partesFecha = fechaInput.split("/");
            int dia = Integer.parseInt(partesFecha[0]);
            int mes = Integer.parseInt(partesFecha[1]);
            int anio = Integer.parseInt(partesFecha[2]);

            // Crear una instancia de Fecha con los valores ingresados
            Fecha fechaBuscada = new Fecha(dia, mes, anio);

            // Filtrar las facturas por la fecha especificada
            List<CabeceraDeFactura> facturasEncontradas = listaFacturas.stream()
                    .filter(factura -> factura.getFecha().equals(fechaBuscada))
                    .toList();

            // Mostrar resultados
            if (facturasEncontradas.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se encontraron facturas para la fecha: " + fechaBuscada, "Resultado de la Búsqueda", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder resultado = new StringBuilder("Facturas encontradas para la fecha: " + fechaBuscada + "\n\n");
                for (CabeceraDeFactura factura : facturasEncontradas) {
                    resultado.append(factura).append("\n\n");
                }
                JOptionPane.showMessageDialog(null, resultado.toString(), "Facturas Encontradas", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error al procesar la fecha. Verifique que sea válida y esté en formato DD/MM/AAAA.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}




