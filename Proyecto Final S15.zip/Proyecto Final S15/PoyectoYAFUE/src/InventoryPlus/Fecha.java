package InventoryPlus;

import java.util.Calendar;


public class Fecha {
    private int dia;
    private int mes;
    private int anio;

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public static Fecha hoy() {
        Calendar calendario = Calendar.getInstance();
        int dia = calendario.get(Calendar.DAY_OF_MONTH);
        int mes = calendario.get(Calendar.MONTH) + 1; // Los meses empiezan desde 0
        int anio = calendario.get(Calendar.YEAR);
        return new Fecha(dia, mes, anio);
    }

    @Override
    public String toString() {
        return dia + "/" + mes + "/" + anio;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Fecha otraFecha = (Fecha) obj;
        return dia == otraFecha.dia && mes == otraFecha.mes && anio == otraFecha.anio;
    }

    @Override
    public int hashCode() {
        int result = dia;
        result = 31 * result + mes;
        result = 31 * result + anio;
        return result;
    }
}