package InventoryPlus;

public class DetallePedido {

    private Producto producto;
    private int cantidad;
    private Proveedor proveedor;

    public DetallePedido(Producto producto, int cantidad, Proveedor proveedor) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.proveedor = proveedor;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    @Override
    public String toString() {
        return "Producto: " + producto.getNombre() +
                " | Cantidad: " + cantidad +
                " | Proveedor: " + proveedor.getNombre();
    }
}

