package InventoryPlus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// pedido factura manager tenía mas funciones porque estab planeado como aydua a la gestión del proceso de inventario


public class PedidoFacturaManager {
    private static List<Pedido> listaPedidos = new ArrayList<>();
    private static List<CabeceraDeFactura> listaFacturas = new ArrayList<>();

    public static void agregarPedido(Pedido pedido) {
        listaPedidos.add(pedido);
    }

    public static CabeceraDeFactura buscarFacturaPorNumero(List<CabeceraDeFactura> listaFacturas, int numFactura) {
        Optional<CabeceraDeFactura> facturaOpt = listaFacturas.stream()
                .filter(factura -> factura.getNumero() == numFactura)
                .findFirst();
        return facturaOpt.orElse(null);
    }
}
