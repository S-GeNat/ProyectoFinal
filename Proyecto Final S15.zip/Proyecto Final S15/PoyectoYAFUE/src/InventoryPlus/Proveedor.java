package InventoryPlus;

import java.util.List;

public class Proveedor {
    private String id;
    private String nombre;
    private String telefono;
    private List<Producto> productosAsociados;


    public Proveedor(String id, String nombre, String telefono, List<Producto> productosAsociados) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.productosAsociados = productosAsociados;
    }


    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }


    public String getNombre() {
        return nombre;
    }


    public List<Producto> getProductosAsociados() {
        return productosAsociados;
    }


    @Override
    public String toString() {
        return "Proveedor [ID: " + id + ", Nombre: " + nombre + ", Teléfono: " + telefono + "]";
    }
}
