package InventoryPlus;

/**
 * Clase que representa un producto en el inventario.
 */
public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;
    private String categoria;
    private Proveedor proveedor; // Nuevo atributo

    /**
     * Constructor que inicializa un nuevo producto.
     *
     * @param nombre     El nombre del producto.
     * @param precio     El precio del producto.
     * @param cantidad   La cantidad del producto.
     * @param categoria  La categoría del producto.
     * @param proveedor  El proveedor del producto.
     */
    public Producto(String nombre, double precio, int cantidad, String categoria, Proveedor proveedor) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.categoria = categoria;
        this.proveedor = proveedor;
    }

    // Getters y Setters

    public Proveedor getProveedor() {
        return proveedor;
    }


    public boolean reducirCantidad(int cantidadVendida) {
        if (cantidadVendida <= cantidad) {
            this.cantidad -= cantidadVendida;
            return true;
        }
        return false;
    }

    public void agregarCantidad(int cantidad) {
        if (cantidad > 0) {
            this.cantidad += cantidad;
        } else {
            System.out.println("La cantidad a agregar debe ser mayor que cero.");
        }
    }


    public int getCantidad() {
        return cantidad;
    }


    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }


    public String getCategoria() {
        return categoria;
    }

    @Override
    public String toString() {
        return "Producto\n" + nombre + '\'' + ", precio $" + precio + ", cantidad: " + cantidad + ", categoria: " + categoria + '\'';
    }
}
