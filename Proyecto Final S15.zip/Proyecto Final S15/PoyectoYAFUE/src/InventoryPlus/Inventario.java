package InventoryPlus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public class Inventario {
    private List<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    // Metodo agregarProducto que espera dos argumentos
    public void agregarProducto(Producto producto, Proveedor proveedor) {
        productos.add(producto);
        // Supongamos que hacemos algo con el proveedor, por ejemplo, agregarlo a una lista de proveedores
    }

    // Otro metodo agregarProducto que tal vez espera otra cosa
    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public Producto buscarProducto(String nombre) {
        return productos.stream()
                .filter(producto -> producto.getNombre().equalsIgnoreCase(nombre))
                .findFirst()
                .orElse(null);
    }

    public List<Producto> getProductos() {
        return productos;
    }
}