package InventoryPlus;


public class Cliente {
    private String cedula;
    private String nombre;
    private String telefono;
    private String correo;

    public Cliente(String cedula, String nombre, String telefono, String correo) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public boolean validarCedula() {
        if (cedula.length() != 10) {
            System.out.println("La cédula debe tener 10 dígitos.");
            return false;
        }

        int suma = 0;
        int[] a = new int[cedula.length() / 2];
        int[] b = new int[cedula.length() / 2];
        int c = 0;
        int d = 1;

        for (int i = 0; i < cedula.length() / 2; i++) {
            a[i] = Integer.parseInt(String.valueOf(cedula.charAt(c)));
            c += 2;
            if (i < (cedula.length() / 2) - 1) {
                b[i] = Integer.parseInt(String.valueOf(cedula.charAt(d)));
                d += 2;
            }
        }

        for (int i = 0; i < a.length; i++) {
            a[i] *= 2;
            if (a[i] > 9) {
                a[i] -= 9;
            }
            suma += a[i] + b[i];
        }

        int aux = suma / 10;
        int dec = (aux + 1) * 10;
        int digitoVerificador = Integer.parseInt(String.valueOf(cedula.charAt(cedula.length() - 1)));

        return (dec - suma) == digitoVerificador || (suma % 10 == 0 && digitoVerificador == 0);
    }

    public boolean validarTelefono() {
        return telefono.matches("\\d+"); // Acepta solo números
    }

    public boolean validarNombre() {
        return nombre.matches("[a-zA-Z\\s]+"); // Acepta solo letras y espacios
    }

    public boolean validarCorreo() {
        return correo.matches("[^\\s]+@[a-zA-Z0-9-]+\\.[a-zA-Z]{2,3}"); // Acepta correos sin espacios
    }

    @Override
    public String toString() {
        return "\nCedula: " + cedula +
                "\nNombre: " + nombre +
                "\nTelefono: " + telefono +
                "\nCorreo: " + correo;
    }
}
