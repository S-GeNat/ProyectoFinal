package InventoryPlus;

import java.util.ArrayList;
import java.util.List;


public class Pedido {
    private Empleado empleado;
    private List<DetallePedido> detalles;

    public Pedido(Empleado empleado) {
        this.empleado = empleado;
        this.detalles = new ArrayList<>();
    }

    public void agregarDetalle(Producto producto, int cantidad, Proveedor proveedor) {
        detalles.add(new DetallePedido(producto, cantidad, proveedor));
    }

    public List<DetallePedido> getDetalles() {
        return detalles;
    }

    public String mostrarPedido() {
        StringBuilder pedidoDetails = new StringBuilder("Pedido realizado por Empleado:\n");
        pedidoDetails.append("ID: ").append(empleado.getId()).append("\n");
        pedidoDetails.append("Nombre: ").append(empleado.getNombre()).append("\n\n");

        pedidoDetails.append("Detalles del Pedido:\n");
        for (DetallePedido detalle : detalles) {
            pedidoDetails.append(detalle).append("\n");
        }
        return pedidoDetails.toString();
    }
}

