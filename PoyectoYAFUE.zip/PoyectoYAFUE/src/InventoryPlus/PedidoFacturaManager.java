package InventoryPlus;

import java.util.ArrayList;
import java.util.List;

public class PedidoFacturaManager {
    private static List<Pedido> listaPedidos = new ArrayList<>();
    private static List<CabeceraDeFactura> listaFacturas = new ArrayList<>();

    // Metodo para agregar un pedido
    public static void agregarPedido(Pedido pedido) {
        listaPedidos.add(pedido);
    }

    // Metodo para obtener todos los pedidos
    public static List<Pedido> obtenerPedidos() {
        return listaPedidos;
    }

    // Metodo para obtener todas las facturas
    public static List<CabeceraDeFactura> obtenerFacturas() {
        return listaFacturas;
    }

    // Mostrar todas las facturas
    public static String mostrarFacturas() {
        StringBuilder facturas = new StringBuilder("=== Facturas ===\n");
        for (CabeceraDeFactura factura : listaFacturas) {
            facturas.append(factura).append("\n\n");
        }
        return facturas.toString();
    }

    // Mostrar todos los pedidos
    public static String mostrarPedidos() {
        StringBuilder pedidos = new StringBuilder("=== Pedidos ===\n");
        for (Pedido pedido : listaPedidos) {
            pedidos.append(pedido.mostrarPedido()).append("\n\n");
        }
        return pedidos.toString();
    }
    public static CabeceraDeFactura buscarFacturaPorNumero(List<CabeceraDeFactura> listaFacturas, int numFactura) {
        for (CabeceraDeFactura factura : listaFacturas) {
            if (factura.getNumero() == numFactura) {
                return factura;
            }
        }
        return null; // Si no se encuentra la factura
    }


}
