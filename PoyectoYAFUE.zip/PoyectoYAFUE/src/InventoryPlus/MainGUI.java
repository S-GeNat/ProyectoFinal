package InventoryPlus;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class MainGUI {

    private static Inventario inventario;
    private static List<Cliente> clientes;
    private static JFrame ventanaInicial;
    private static List<CabeceraDeFactura> listaFacturas = new ArrayList<>();
    private static List<Proveedor> listadeProveedores = new ArrayList<>();

    public static void main(String[] args) {
        // Inicializar inventario y clientes
        inventario = new Inventario();
        inventario.agregarProducto(new Producto("Manzana", 0.5, 100, "Fruta"));
        inventario.agregarProducto(new Producto("Arroz", 1.2, 50, "Grano"));
        inventario.agregarProducto(new Producto("Leche", 1.5, 30, "Lácteo"));

        clientes = new ArrayList<>();
        clientes.add(new Cliente("1751834316", "Alejandro Carrera", "0994259393", "alejandrocarrera2004@gmail.com"));
        clientes.add(new Cliente("1719259119", "Pepito Fulano", "0994325228", "pepito24@gmail.com"));


        // Mostrar la ventana inicial
        mostrarVentanaPrincipal();
    }

    private static void mostrarVentanaPrincipal() {
        JFrame ventanaPrincipal = new JFrame("Gestión de Ventas y Pedidos");
        ventanaPrincipal.setSize(400, 300);
        ventanaPrincipal.setLayout(new GridLayout(3, 1)); // Tres filas, una por cada botón

        // Botones para las acciones
        JButton botonVentas = new JButton("Ventas");
        JButton botonPedido = new JButton("Pedido");
        JButton botonBusqueda = new JButton("Búsqueda");

        // Agregar los botones a la ventana
        ventanaPrincipal.add(botonVentas);
        ventanaPrincipal.add(botonPedido);
        ventanaPrincipal.add(botonBusqueda);

        // Mostrar la ventana principal
        ventanaPrincipal.setVisible(true);
        Empleado empleado = new Empleado("12345", "Juan Perez","0963004475");
        Proveedor proveedor = new Proveedor("1", "Proveedor ABC", "555-1234", new ArrayList<>());
        listadeProveedores.add(proveedor);

        // Eventos para los botones
        botonVentas.addActionListener(e -> {
            // Aquí puedes llamar a la función relacionada con "Ventas"
            mostrarVentanaInicial(ventanaPrincipal);
        });

        botonPedido.addActionListener(e -> {
            // Llamar a la función para agregar pedido
            manejarPedido(empleado, proveedor, ventanaPrincipal); // Aquí pasa el empleado, proveedor y ventana principal
            ventanaPrincipal.setVisible(false);
        });

        botonBusqueda.addActionListener(e -> {
            // Aquí puedes llamar a la función relacionada con "Búsqueda"
            ventanaPrincipal.setVisible(false); // Ocultar ventana principal
            mostrarPanelBusqueda(ventanaPrincipal,listaFacturas);
        });
    }

    private static void mostrarPanelBusqueda(JFrame ventanaPrincipal, List<CabeceraDeFactura> listaFacturas) {
        // Crear un nuevo JFrame para el panel de búsqueda
        JFrame ventanaBusqueda = new JFrame("Panel de Búsqueda");
        ventanaBusqueda.setSize(400, 200);
        ventanaBusqueda.setLayout(new GridLayout(2, 1)); // Dos filas, una por cada botón

        // Botones para las opciones de búsqueda
        JButton botonBuscarPorFecha = new JButton("Búsqueda por Fecha");
        JButton botonBuscarPorNumero = new JButton("Búsqueda por Número de Factura");

        // Agregar botones al panel
        ventanaBusqueda.add(botonBuscarPorFecha);
        ventanaBusqueda.add(botonBuscarPorNumero);

        // Mostrar la ventana de búsqueda
        ventanaBusqueda.setVisible(true);

        // Eventos para los botones de búsqueda
        botonBuscarPorFecha.addActionListener(e -> buscarFacturasPorFecha(listaFacturas));

        botonBuscarPorNumero.addActionListener(e -> {
            String numeroString = JOptionPane.showInputDialog(ventanaBusqueda, "Ingrese el número de factura:");
            if (numeroString != null && !numeroString.isEmpty()) {
                try {
                    int numeroFactura = Integer.parseInt(numeroString);
                    CabeceraDeFactura facturaEncontrada = PedidoFacturaManager.buscarFacturaPorNumero(listaFacturas, numeroFactura);

                    if (facturaEncontrada != null) {
                        JOptionPane.showMessageDialog(ventanaBusqueda, facturaEncontrada.toString(), "Factura Encontrada", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(ventanaBusqueda, "No se encontró ninguna factura con ese número.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(ventanaBusqueda, "Número inválido. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Evento al cerrar la ventana de búsqueda
        ventanaBusqueda.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                ventanaBusqueda.dispose(); // Cerrar ventana de búsqueda
                ventanaPrincipal.setVisible(true); // Volver a mostrar la ventana principal
            }
        });
    }


    private static void mostrarVentanaInicial(JFrame ventanaPrincipal) {
        if (ventanaInicial == null) {
            ventanaInicial = new JFrame("Sistema de Facturación");
            ventanaInicial.setSize(400, 200);

            ventanaInicial.setLayout(new BorderLayout());

            JLabel etiquetaCedula = new JLabel("Ingrese la cédula:");
            JTextField campoCedula = new JTextField(10);
            JButton botonValidar = new JButton("Validar");

            JPanel panel = new JPanel();
            panel.add(etiquetaCedula);
            panel.add(campoCedula);
            panel.add(botonValidar);

            ventanaInicial.add(panel, BorderLayout.CENTER);

            botonValidar.addActionListener(e -> {
                String cedula = campoCedula.getText().trim();

                if (cedula.isEmpty() || !cedula.matches("\\d+")) {
                    JOptionPane.showMessageDialog(ventanaInicial, "La cédula debe contener solo números y no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Cliente clienteTemporal = new Cliente(cedula, "", "", "");
                if (!clienteTemporal.validarCedula()) {
                    JOptionPane.showMessageDialog(ventanaInicial, "Cédula inválida. Por favor, ingrese una cédula válida.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Cliente clienteExistente = clientes.stream()
                        .filter(cliente -> cliente.getCedula().equals(cedula))
                        .findFirst()
                        .orElse(null);

                if (clienteExistente != null) {
                    // Mostrar datos del cliente registrado
                    String mensaje = "Usuario registrado:\n" +
                            "Cédula: " + clienteExistente.getCedula() + "\n" +
                            "Nombre: " + clienteExistente.getNombre() + "\n" +
                            "Teléfono: " + clienteExistente.getTelefono() + "\n" +
                            "Correo: " + clienteExistente.getCorreo();
                    JOptionPane.showMessageDialog(ventanaInicial, mensaje, "Cliente Registrado", JOptionPane.INFORMATION_MESSAGE);

                    // Pasar directamente a la ventana de productos
                    ventanaInicial.setVisible(false);
                    mostrarVentanaProductos(clienteExistente);
                } else {
                    JOptionPane.showMessageDialog(ventanaInicial, "Usuario no registrado. Proceda a registrar sus datos.");
                    ventanaInicial.setVisible(false);
                    mostrarVentanaRegistro(null, campoCedula.getText());
                }
            });
        }
        ventanaInicial.setVisible(true);
    }

    private static void mostrarVentanaRegistro(Cliente cliente, String cedulaIngresada) {
        JFrame ventanaRegistro = new JFrame("Registro de Usuario");
        ventanaRegistro.setSize(400, 300);
        ventanaRegistro.setLayout(new GridLayout(5, 2));

        JTextField campoCedula = new JTextField(cliente != null ? cliente.getCedula() : cedulaIngresada);
        JTextField campoNombre = new JTextField(cliente != null ? cliente.getNombre() : "");
        JTextField campoTelefono = new JTextField(cliente != null ? cliente.getTelefono() : "");
        JTextField campoCorreo = new JTextField(cliente != null ? cliente.getCorreo() : "");

        JButton botonSiguiente = new JButton("Siguiente");

        ventanaRegistro.add(new JLabel("Cédula:"));
        ventanaRegistro.add(campoCedula);
        ventanaRegistro.add(new JLabel("Nombre:"));
        ventanaRegistro.add(campoNombre);
        ventanaRegistro.add(new JLabel("Teléfono:"));
        ventanaRegistro.add(campoTelefono);
        ventanaRegistro.add(new JLabel("Correo:"));
        ventanaRegistro.add(campoCorreo);
        ventanaRegistro.add(new JLabel(""));
        ventanaRegistro.add(botonSiguiente);

        ventanaRegistro.setVisible(true);

        botonSiguiente.addActionListener(e -> {
            String cedula = campoCedula.getText().trim();
            String nombre = campoNombre.getText().trim();
            String telefono = campoTelefono.getText().trim();
            String correo = campoCorreo.getText().trim();

            if (cedula.isEmpty() || nombre.isEmpty() || telefono.isEmpty() || correo.isEmpty()) {
                JOptionPane.showMessageDialog(ventanaRegistro, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Cliente tempCliente = new Cliente(cedula, nombre, telefono, correo);

            if (!tempCliente.validarCedula()) {
                JOptionPane.showMessageDialog(ventanaRegistro, "Cédula inválida. Por favor, ingrese una cédula válida.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!tempCliente.validarNombre()) {
                JOptionPane.showMessageDialog(ventanaRegistro, "Nombre inválido. Por favor, ingrese un nombre válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!tempCliente.validarTelefono()) {
                JOptionPane.showMessageDialog(ventanaRegistro, "Teléfono inválido. Por favor, ingrese un teléfono válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!tempCliente.validarCorreo()) {
                JOptionPane.showMessageDialog(ventanaRegistro, "Correo inválido. Por favor, ingrese un correo válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Cliente nuevoCliente = cliente != null ? cliente : tempCliente;
            if (cliente == null) {
                clientes.add(nuevoCliente);
            }

            ventanaRegistro.dispose();
            mostrarVentanaProductos(nuevoCliente);
        });
    }

    private static void mostrarVentanaProductos(Cliente cliente) {
        JFrame ventanaProductos = new JFrame("Seleccionar Productos");
        ventanaProductos.setSize(500, 400);
        ventanaProductos.setLayout(new BorderLayout());

        JTextArea areaProductos = new JTextArea();
        areaProductos.setEditable(false);

        StringBuilder productosTexto = new StringBuilder("=== Productos Disponibles ===\n");
        for (Producto producto : inventario.getProductos()) {
            productosTexto.append(producto.getNombre())
                    .append(" - Precio: $").append(producto.getPrecio())
                    .append(" - Stock: ").append(producto.getCantidad())
                    .append("\n");
        }
        areaProductos.setText(productosTexto.toString());

        JTextField campoProducto = new JTextField();
        JTextField campoCantidad = new JTextField();
        JButton botonAgregar = new JButton("Agregar Producto");
        JButton botonFactura = new JButton("Crear Factura");

        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new GridLayout(4, 2));
        panelInferior.add(new JLabel("Producto:"));
        panelInferior.add(campoProducto);
        panelInferior.add(new JLabel("Cantidad:"));
        panelInferior.add(campoCantidad);
        panelInferior.add(botonAgregar);
        panelInferior.add(botonFactura);
        panelInferior.add(new JLabel(""));

        ventanaProductos.add(new JScrollPane(areaProductos), BorderLayout.CENTER);
        ventanaProductos.add(panelInferior, BorderLayout.SOUTH);
        ventanaProductos.setVisible(true);

        CabeceraDeFactura factura = new CabeceraDeFactura(cliente);

        botonAgregar.addActionListener(e -> {
            String nombreProducto = campoProducto.getText().trim();
            String cantidadTexto = campoCantidad.getText().trim();

            if (nombreProducto.isEmpty() || cantidadTexto.isEmpty()) {
                JOptionPane.showMessageDialog(ventanaProductos, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Producto productoSeleccionado = inventario.buscarProducto(nombreProducto);
            if (productoSeleccionado == null) {
                JOptionPane.showMessageDialog(ventanaProductos, "El producto no existe en el inventario.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int cantidad = 0;
            try {
                cantidad = Integer.parseInt(cantidadTexto);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(ventanaProductos, "La cantidad debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (cantidad <= 0 || cantidad > productoSeleccionado.getCantidad()) {
                JOptionPane.showMessageDialog(ventanaProductos, "Cantidad inválida o stock insuficiente.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Reducir la cantidad en el inventario
            boolean exito = productoSeleccionado.reducirCantidad(cantidad);
            if (exito) {
                // Agregar o actualizar el detalle en la factura
                factura.agregarDetalle(productoSeleccionado, cantidad);

                // Actualizar la lista de productos en el área de texto
                StringBuilder productosActualizados = new StringBuilder("=== Productos Disponibles ===\n");
                for (Producto producto : inventario.getProductos()) {
                    productosActualizados.append(producto.getNombre())
                            .append(" - Precio: $").append(producto.getPrecio())
                            .append(" - Stock: ").append(producto.getCantidad())
                            .append("\n");
                }
                areaProductos.setText(productosActualizados.toString());

                JOptionPane.showMessageDialog(ventanaProductos, "Producto agregado a la factura.");
            } else {
                JOptionPane.showMessageDialog(ventanaProductos, "Error al reducir la cantidad del producto.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        botonFactura.addActionListener(e -> {
            if (!factura.tieneProductos()) {
                JOptionPane.showMessageDialog(ventanaProductos, "No hay productos en la factura.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Llamar al metodo mostrarVentanaFactura para mostrar la factura
            listaFacturas.add(factura);
            mostrarVentanaFactura(factura);

            // Cerrar la ventana actual
            ventanaProductos.dispose();
        });
    }


    private static void mostrarVentanaFactura(CabeceraDeFactura factura) {
        JFrame ventanaFactura = new JFrame("Factura");
        ventanaFactura.setSize(400, 400);

        JTextArea areaFactura = new JTextArea();
        areaFactura.setEditable(false);
        areaFactura.setText(factura.toString());

        JScrollPane scrollPane = new JScrollPane(areaFactura);
        ventanaFactura.add(scrollPane);

        ventanaFactura.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventanaFactura.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                super.windowClosing(e);
                // Volver a mostrar la ventana inicial
                ventanaInicial.setVisible(true);
            }
        });

        ventanaFactura.setVisible(true);
    }

    private static void manejarPedido(Empleado empleado, Proveedor proveedor, JFrame ventanaPrincipal) {
        JFrame ventanaPedido = new JFrame("Realizar Pedido");
        ventanaPedido.setSize(500, 400);
        ventanaPedido.setLayout(new BorderLayout());

        JTextArea areaProductos = new JTextArea();
        areaProductos.setEditable(false);

        // Mostrar los productos disponibles en el inventario
        StringBuilder productosTexto = new StringBuilder("=== Productos Disponibles ===\n");
        for (Producto producto : inventario.getProductos()) {
            productosTexto.append(producto.getNombre())
                    .append(" - Precio: $").append(producto.getPrecio())
                    .append(" - Stock: ").append(producto.getCantidad())
                    .append("\n");
        }
        areaProductos.setText(productosTexto.toString());

        JTextField campoProducto = new JTextField();
        JTextField campoCantidad = new JTextField();
        JButton botonAgregar = new JButton("Agregar Producto");
        JButton botonPedido = new JButton("Realizar Pedido");

        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new GridLayout(4, 2));
        panelInferior.add(new JLabel("Producto:"));
        panelInferior.add(campoProducto);
        panelInferior.add(new JLabel("Cantidad:"));
        panelInferior.add(campoCantidad);
        panelInferior.add(botonAgregar);
        panelInferior.add(botonPedido);
        panelInferior.add(new JLabel(""));

        ventanaPedido.add(new JScrollPane(areaProductos), BorderLayout.CENTER);
        ventanaPedido.add(panelInferior, BorderLayout.SOUTH);
        ventanaPedido.setVisible(true);

        // Crear un nuevo pedido
        AtomicReference<Pedido> pedido = new AtomicReference<>(new Pedido(empleado, proveedor));  // Proveedor inicial

        // Acción para agregar productos al pedido
        botonAgregar.addActionListener(e -> {
            String nombreProducto = campoProducto.getText().trim();
            String cantidadTexto = campoCantidad.getText().trim();

            if (nombreProducto.isEmpty() || cantidadTexto.isEmpty()) {
                JOptionPane.showMessageDialog(ventanaPedido, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Producto productoSeleccionado = inventario.buscarProducto(nombreProducto);

            if (productoSeleccionado == null) {
                // Producto no existe, preguntar si desea crearlo
                int opcion = JOptionPane.showConfirmDialog(ventanaPedido, "El producto no existe en el inventario. ¿Desea crearlo?", "Producto no encontrado", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.NO_OPTION) {
                    return;
                }

                // Buscar proveedor existente o crear uno nuevo
                String nombreProveedor = JOptionPane.showInputDialog(ventanaPedido, "Ingrese el nombre del proveedor:");
                Proveedor proveedorExistente = null;

                for (Proveedor proveedorIterado : listadeProveedores) {
                    if (proveedorIterado.getNombre().equalsIgnoreCase(nombreProveedor)) {
                        proveedorExistente = proveedorIterado;
                        break; // Sale del bucle si encuentra el proveedor
                    }
                }

                if (proveedorExistente == null) {
                    // Si no se encontró un proveedor existente, creamos uno nuevo
                    String telefonoProveedor = JOptionPane.showInputDialog(ventanaPedido, "Ingrese el teléfono del proveedor:");
                    proveedorExistente = new Proveedor(String.valueOf(listadeProveedores.size() + 1), nombreProveedor, telefonoProveedor, new ArrayList<>());
                    listadeProveedores.add(proveedorExistente);
                    JOptionPane.showMessageDialog(ventanaPedido, "Proveedor creado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(ventanaPedido, "Proveedor ya existente, asociado al nuevo producto.");
                }

                // Crear el producto
                double precioProducto;
                try {
                    precioProducto = Double.parseDouble(JOptionPane.showInputDialog(ventanaPedido, "Ingrese el precio del producto:"));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(ventanaPedido, "Precio inválido. Intente nuevamente.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Producto nuevoProducto = new Producto(nombreProducto, precioProducto, 0, "Sin categoría");
                proveedorExistente.getProductosAsociados().add(nuevoProducto);
                inventario.agregarProducto(nuevoProducto);

                JOptionPane.showMessageDialog(ventanaPedido, "Producto creado exitosamente y asociado al proveedor.");
                productoSeleccionado = nuevoProducto;

                // Actualizar el proveedor del pedido
                pedido.set(new Pedido(empleado, proveedorExistente));  // Actualizar el pedido con el nuevo proveedor
            }

            // Agregar el producto al pedido
            int cantidad;
            try {
                cantidad = Integer.parseInt(cantidadTexto);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(ventanaPedido, "La cantidad debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            pedido.get().agregarProducto(productoSeleccionado, cantidad);
            productoSeleccionado.agregarCantidad(cantidad);

            // Actualizar el inventario en el área de texto
            StringBuilder productosActualizados = new StringBuilder("=== Productos Disponibles ===\n");
            for (Producto producto : inventario.getProductos()) {
                productosActualizados.append(producto.getNombre())
                        .append(" - Precio: $").append(producto.getPrecio())
                        .append(" - Stock: ").append(producto.getCantidad())
                        .append("\n");
            }
            areaProductos.setText(productosActualizados.toString());
            JOptionPane.showMessageDialog(ventanaPedido, "Producto agregado al pedido.");
        });

        // Acción para realizar el pedido
        botonPedido.addActionListener(e -> {
            if (pedido.get().getProductos().isEmpty()) {
                JOptionPane.showMessageDialog(ventanaPedido, "No se puede realizar un pedido sin productos. Agregue al menos un producto.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Agregar el pedido a la lista de pedidos
            PedidoFacturaManager.agregarPedido(pedido.get());

            // Mostrar detalles del pedido
            JOptionPane.showMessageDialog(ventanaPedido, pedido.get().mostrarPedido(), "Pedido Realizado", JOptionPane.INFORMATION_MESSAGE);

            // Cerrar la ventana de productos
            ventanaPedido.dispose();

            // Mostrar la ventana principal después de realizar el pedido
            ventanaPrincipal.setVisible(true);
        });
    }


    private static void buscarFacturasPorFecha(List<CabeceraDeFactura> listaFacturas) {
        // Solicitar la fecha al usuario
        String fechaInput = JOptionPane.showInputDialog(null, "Ingrese la fecha en formato DD/MM/AAAA:", "Búsqueda por Fecha", JOptionPane.QUESTION_MESSAGE);

        // Validar la entrada
        if (fechaInput == null || !fechaInput.matches("\\d{2}/\\d{2}/\\d{4}")) {
            JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Use el formato DD/MM/AAAA.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Dividir la entrada en día, mes y año
            String[] partesFecha = fechaInput.split("/");
            int dia = Integer.parseInt(partesFecha[0]);
            int mes = Integer.parseInt(partesFecha[1]);
            int anio = Integer.parseInt(partesFecha[2]);

            // Crear una instancia de Fecha con los valores ingresados
            Fecha fechaBuscada = new Fecha(dia, mes, anio);

            // Filtrar las facturas por la fecha especificada
            List<CabeceraDeFactura> facturasEncontradas = listaFacturas.stream()
                    .filter(factura -> factura.getFecha().equals(fechaBuscada))
                    .toList();

            // Mostrar resultados
            if (facturasEncontradas.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se encontraron facturas para la fecha: " + fechaBuscada, "Resultado de la Búsqueda", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder resultado = new StringBuilder("Facturas encontradas para la fecha: " + fechaBuscada + "\n\n");
                for (CabeceraDeFactura factura : facturasEncontradas) {
                    resultado.append(factura).append("\n\n");
                }
                JOptionPane.showMessageDialog(null, resultado.toString(), "Facturas Encontradas", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error al procesar la fecha. Verifique que sea válida y esté en formato DD/MM/AAAA.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}




