package InventoryPlus;

public class Cliente {
    private String cedula;
    private String nombre;
    private String telefono;
    private String correo;

    public Cliente(String cedula, String nombre, String telefono, String correo) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    // Validar cédula ecuatoriana (10 dígitos, usando el algoritmo proporcionado)
    public boolean validarCedula() {
        if (cedula.length() != 10) {
            System.out.println("La cédula debe tener 10 dígitos.");
            return false;
        }

        int suma = 0;
        int[] a = new int[cedula.length() / 2];
        int[] b = new int[cedula.length() / 2];
        int c = 0;
        int d = 1;

        for (int i = 0; i < cedula.length() / 2; i++) {
            a[i] = Integer.parseInt(String.valueOf(cedula.charAt(c)));
            c = c + 2;
            if (i < (cedula.length() / 2) - 1) {
                b[i] = Integer.parseInt(String.valueOf(cedula.charAt(d)));
                d = d + 2;
            }
        }

        for (int i = 0; i < a.length; i++) {
            a[i] = a[i] * 2;
            if (a[i] > 9) {
                a[i] = a[i] - 9;
            }
            suma = suma + a[i] + b[i];
        }

        int aux = suma / 10;
        int dec = (aux + 1) * 10;

        if ((dec - suma) == Integer.parseInt(String.valueOf(cedula.charAt(cedula.length() - 1)))) {
            return true;
        } else return suma % 10 == 0 && cedula.charAt(cedula.length() - 1) == '0';
    }

    // Validar que el teléfono solo tenga números
    public boolean validarTelefono() {
        return telefono.matches("\\d+");  // Acepta solo números
    }

    // Validar que el nombre solo tenga letras
    public boolean validarNombre() {
        return nombre.matches("[a-zA-Z\\s]+");  // Acepta solo letras y espacios
    }

    // Validar el correo (sin espacios y que termine en .com, .ec, etc.)
    public boolean validarCorreo() {
        return correo.matches("[^\\s]+@[a-zA-Z0-9-]+\\.[a-zA-Z]{2,3}");  // Acepta correos sin espacios
    }

    @Override
    public String toString() {
        return  "\nCedula: " + cedula +
                "\nNombre: " + nombre +
                "\nTelefono: " + telefono +
                "\nCorreo: " + correo;
    }
}
