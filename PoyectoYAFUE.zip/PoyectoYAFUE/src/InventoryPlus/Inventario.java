package InventoryPlus;

import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private List<InventoryPlus.Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public List<InventoryPlus.Producto> getProductos() {
        return productos;
    }

    public void agregarProducto(InventoryPlus.Producto producto) {
        productos.add(producto);
    }

    public InventoryPlus.Producto buscarProducto(String nombre) {
        for (InventoryPlus.Producto producto : productos) {
            if (producto.getNombre().equalsIgnoreCase(nombre)) {
                return producto;
            }
        }
        return null;
    }

}
