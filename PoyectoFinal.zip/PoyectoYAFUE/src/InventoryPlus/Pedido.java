package InventoryPlus;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private Empleado empleado;
    private Proveedor proveedor;
    private List<Producto> productos;
    private List<Integer> cantidades;

    public Pedido(Empleado empleado, Proveedor proveedor) {
        this.empleado = empleado;
        this.proveedor = proveedor;
        this.productos = new ArrayList<>();
        this.cantidades = new ArrayList<>();
    }

    public void agregarProducto(Producto producto, int cantidad) {
        productos.add(producto);
        cantidades.add(cantidad);
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public List<Integer> getCantidades() {
        return cantidades;
    }

    public String mostrarPedido() {
        StringBuilder pedidoDetails = new StringBuilder("Pedido realizado por Empleado: " + "\nID: "+empleado.getId()+"\nNombre:"+empleado.getNombre() + "\nProveedor: "+ "\nID: "+ proveedor.getId()+"\nNombre: "+proveedor.getNombre() + "\nProductos solicitados:\n");
        for (int i = 0; i < productos.size(); i++) {
            pedidoDetails.append(productos.get(i).getNombre()).append(" - Cantidad: ").append(cantidades.get(i)).append("\n");
        }
        return pedidoDetails.toString();
    }
}


