package InventoryPlus;

import java.util.ArrayList;
import java.util.List;

public class CabeceraDeFactura {
    private Fecha fecha;
    private int numero;
    private Cliente cliente;
    private List<DetalleDeFactura> detalles;

    public static int numFactura = 0;
    public int getNumero() {
        return numero;
    }
    public CabeceraDeFactura(Cliente cliente) {
        this.cliente = cliente;
        numFactura++;
        this.numero = numFactura;
        this.fecha = Fecha.hoy();
        this.detalles = new ArrayList<>();
    }

    public void agregarDetalle(InventoryPlus.Producto producto, int cantidad) {
        DetalleDeFactura detalleExistente = detalles.stream()
                .filter(detalle -> detalle.getProducto().equals(producto))
                .findFirst()
                .orElse(null);

        if (detalleExistente != null) {
            // Actualizar cantidad y subtotal del detalle existente
            detalleExistente.setCantidad(detalleExistente.getCantidad() + cantidad);
            detalleExistente.actualizarSubtotal();
        } else {
            // Agregar un nuevo detalle sin reducir cantidad
            detalles.add(new DetalleDeFactura(producto, cantidad));
        }
    }

    public boolean tieneProductos() {
        return detalles != null && !detalles.isEmpty();
    }

    public Fecha getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        StringBuilder facturaTexto = new StringBuilder();
        facturaTexto.append("Factura #").append(numero).append("\n");
        facturaTexto.append("Fecha: ").append(fecha).append("\n");
        facturaTexto.append("Cliente: ").append(cliente).append("\n");
        facturaTexto.append("Detalles:\n");
        double subtotal = 0;
        for (DetalleDeFactura detalle : detalles) {
            facturaTexto.append(detalle).append("\n");
            subtotal += detalle.getSubtotal();
        }
        double iva = subtotal * 0.12;
        double total = subtotal + iva;
        facturaTexto.append("Subtotal: $").append(String.format("%.2f", subtotal)).append("\n");
        facturaTexto.append("IVA (12%): $").append(String.format("%.2f", iva)).append("\n");
        facturaTexto.append("Total a pagar: $").append(String.format("%.2f", total));
        return facturaTexto.toString();
    }
}
