package InventoryPlus;

public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;
    private String categoria;

    public Producto(String nombre, double precio, int cantidad, String categoria) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.categoria = categoria;
    }

    public boolean reducirCantidad(int cantidadVendida) {
        System.out.println("Cantidad actual: " + this.cantidad);
        System.out.println("Cantidad vendida: " + cantidadVendida);
        if (cantidadVendida <= cantidad) {
            this.cantidad -= cantidadVendida;
            System.out.println("Nueva cantidad: " + this.cantidad);
            return true;
        }
        return false;
    }

    public void agregarCantidad(int cantidad) {
        if (cantidad > 0) {
            this.cantidad += cantidad;
        } else {
            System.out.println("La cantidad a agregar debe ser mayor que cero.");
        }
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Producto\n" + nombre + '\'' + ", precio $" + precio + ", cantidad: " + cantidad + ", categoria: " + categoria + '\'';
    }
}
