package InventoryPlus;

public class DetallesPedido {
    private Producto producto;
    private int cantidad;
    private Proveedor proveedor;

    public DetallesPedido(Producto producto, int cantidad, Proveedor proveedor) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.proveedor = proveedor;
    }

    public double calcularSubtotal() {
        return producto.getPrecio() * cantidad;
    }

    @Override
    public String toString() {
        return producto.getNombre() + " | Cantidad: " + cantidad + " | Proveedor: " + proveedor.getNombre() +
                " | Subtotal: $" + String.format("%.2f", calcularSubtotal());
    }
}
